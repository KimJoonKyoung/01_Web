document.querySelector('h1').style.backgroundColor = 'red';
document.querySelector('h2').style.color = 'red';
